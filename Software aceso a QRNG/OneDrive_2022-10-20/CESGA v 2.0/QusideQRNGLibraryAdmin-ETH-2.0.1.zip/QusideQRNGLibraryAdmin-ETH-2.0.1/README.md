To install this library follow these steps:
- Copy libqusideQRNGadmin.so to /usr/lib
- Copy quside_QRNG_admin.h to /usr/include
- Copy quside.conf to /etc/ld.so.conf
