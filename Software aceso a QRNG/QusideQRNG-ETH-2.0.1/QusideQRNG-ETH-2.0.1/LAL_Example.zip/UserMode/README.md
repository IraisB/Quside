# Introduction 
This project shows an example of how to use the Quside QRNG LAL.

# Getting Started
1.	Requeriments 
    - python >= 3.8.0
    - Numpy >= 1.22.2
    - QusideQRNGLibraryUser_ETH == 2.0.0
    - QusideQRNGLALUser == 2.0.0
    
2.  Example
    - Uncompress the zip file containing the example. In the folder where the python example is located
    
        $ python QusideQRNGLALUser_Example.py