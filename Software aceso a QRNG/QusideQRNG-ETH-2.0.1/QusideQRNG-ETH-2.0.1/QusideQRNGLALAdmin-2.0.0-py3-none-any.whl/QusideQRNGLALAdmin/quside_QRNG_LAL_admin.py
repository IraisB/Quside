"""
Copyright (C) 2022 QUSIDE TECHNOLOGIES - All Rights Reserved.

Unauthorized copying of this file, via any medium is strictly prohibited.
"""
from ctypes import c_size_t, c_int32, c_uint32, c_float, c_uint16, c_bool, pointer, POINTER
from QusideQRNGLALUser.quside_QRNG_LAL_user import QusideQRNGLALUser
from enum import IntEnum
from threading import Timer, Thread, Event
import numpy as np
import time


# Define the types we need.
class CtypesEnum(IntEnum):
    """A ctypes-compatible IntEnum superclass."""
    @classmethod
    def from_param(cls, obj):
        return c_int32(obj)


class AlarmType(CtypesEnum):
    LASER_STATUS = 0
    LASER_TEMP = 1
    OPTICAL_PW = 2
    BIAS_MON = 3
    TEMP = 4
    VCC = 5
    VCOMP = 6
    QFACTOR = 7
    SYSTEM_CALIBRATED = 8


class MonitorValue(CtypesEnum):
    OK = 0
    LOW_VALUE = -1
    HIGH_VALUE = -2
    OFF = -3
    OUT_OF_SECURE_RANGE = -4


class CalibrationStatus (CtypesEnum):
    DEFAULT = 0
    CALIBRATING = 1
    CALIB_SUCCED = 2
    CALIB_FAIL = 3
    I2C_ERROR = 4


class QusideQRNGLALAdmin:
    """
    Quside QRNG Library Abstract Layer in Admin mode.

    This class is used to request monitors and random numbers from Python through Quside QRNG library.
    """
    def __init__(self, ip=0, lib='libqusideQRNGadmin.so'):
        """
        Init the class loading the Quside QRNG library.
        """
        self.alarmTime = None

        self.LALUser = QusideQRNGLALUser(ip=ip, lib=lib)

        self.c_lib = self.LALUser.c_lib

    def __del__(self):
        if self.alarmTime is not None:
            self.alarmTime.cancel()

    # region BOARD
    def reset_board(self):
        """
        Reset the boards connected.

        :return: void.
        """
        return self.c_lib.reset()

    def find_boards(self):
        """
        Search Babylon devices connected in the system and initialize
        the lists with the descriptors. THIS IS ONLY USED BY PCIe.

        :return: number of Babylons connected.
        """
        return self.LALUser.find_boards()

    def get_boards(self):
        """
        Returns a list of the devices IDs connected to the system.
        THIS IS ONLY USED BY PCIe.

        :return: List that will contain the devices IDs and
                 number of elements that the list will contain.
        """
        return self.LALUser.get_boards()

    def find_device(self, devID):
        """
        Returns the index of a device contained in the devices list.

        :param devID: Device id to search in the list.
        :return: The index of the devID in the devices list. If the provided
        devID does not exist, this function will return a -1.
        """
        return self.LALUser.find_device(devID)
    # endregion BOARD

    # region CONNECT/DISCONNECT
    def disconnect(self):
        try:
            self.LALUser.disconnect()

        except Exception as e:
            print(e)
    # endregion CONNECT/DISCONNECT

    # region MONITORS
    def monitor_read_temperature(self, devInd):
        """
        Read the temperature monitor.

        :param devInd: index of the device.
        :return: temperature value as float.
        """
        try:
            temp = c_float(0)

            if self.c_lib.monitor_read_temperature(c_uint16(devInd), pointer(temp)) < 0:
                raise Exception('Monitor read temperature error.')

            return temp.value

        except Exception as e:
            print(e)

    def monitor_read_supply_voltage(self, devInd):
        """
        Read the power supply voltage. ONLY FMC-400.

        :param devInd: index of the device.
        :return: voltage value as float array.
        """
        try:
            vcc = pointer(c_float(0))
            nVCCs = c_uint32(0)

            if self.c_lib.monitor_read_supply_voltage(c_uint16(devInd), pointer(vcc), pointer(nVCCs)) < 0:
                raise Exception('Monitor read supply voltage error.')

            return np.array(np.fromiter(vcc, dtype=np.float, count=nVCCs.value))

        except Exception as e:
            print(e)

    def monitor_read_optical_power(self, devInd):
        """
        Read the optical power monitor.

        :param devInd: index of the device.
        :return: optical power value as float array.
        """
        try:
            opPwr = pointer(c_float(0))
            nOpPwrs = c_uint32(0)

            if self.c_lib.monitor_read_optical_power(c_uint16(devInd), pointer(opPwr), pointer(nOpPwrs)) < 0:
                raise Exception('Monitor read optical power error.')

            return np.array(np.fromiter(opPwr, dtype=np.float, count=nOpPwrs.value))

        except Exception as e:
            print(e)

    def monitor_read_bias_monitor(self, devInd):
        """
        Read the bias monitor.

        :param devInd: index of the device.
        :return: bias value as float array.
        """
        try:
            bias = pointer(c_float(0))
            nBias = c_uint32(0)

            if self.c_lib.monitor_read_bias_monitor(c_uint16(devInd), pointer(bias), pointer(nBias)) < 0:
                raise Exception('Monitor read bias monitor error.')

            return np.array(np.fromiter(bias, dtype=np.float, count=nBias.value))

        except Exception as e:
            print(e)

    def quality_Qfactor(self, devInd):
        """
        Read the Q Factor.

        :param devInd: index of the device.
        :return: Q factor value as float.
        """
        try:
            qFactor = c_float(0)

            if self.c_lib.quality_Qfactor(c_uint16(devInd), pointer(qFactor)) < 0:
                raise Exception('Quality Q Factor error.')

            return qFactor.value

        except Exception as e:
            print(e)

    def get_laser_temperatures(self, devInd):
        """
        Reads power supply voltage fo the resistors that heat the laser. ONLY FMC-ONE.

        :param devInd: index of the device.
        :return: laser temperature values as float array.
        """
        try:
            temp = pointer(c_float(0))
            nTemps = c_uint32(0)

            if self.c_lib.get_laser_temperatures(c_uint16(devInd), pointer(temp), pointer(nTemps)) < 0:
                raise Exception('Laser temperature error.')

            return np.array(np.fromiter(temp, dtype=np.float, count=nTemps.value))

        except Exception as e:
            print(e)

    def get_laser_status(self, devInd):
        """
        Reads laser status.

        :param devInd: index of the device.
        :return: laser status values as int array.
        """
        try:
            laserStatus = pointer(c_uint32(0))
            nLasers = c_uint32(0)

            if self.c_lib.get_laser_status(c_uint16(devInd), pointer(laserStatus), pointer(nLasers)) < 0:
                raise Exception('Laser status error.')

            return np.array(np.fromiter(laserStatus, dtype=np.int, count=nLasers.value))

        except Exception as e:
            print(e)

    def get_Vcomp(self, devInd):
        """
        Reads voltage comparator in volts.

        :param devInd: index of the device.
        :return: comparator voltage value as float.
        """
        try:
            vComp = c_float(0)

            if self.c_lib.get_Vcomp(c_uint16(devInd), pointer(vComp)) < 0:
                raise Exception('VCOMP error.')

            return vComp.value

        except Exception as e:
            print(e)

    def get_hmin(self, devInd):
        """
        Reads the minimum entropy of the system. This value only changes after calibration.

        :param devInd: index of the device.
        :return: Hmin value as float.
        """
        try:
            hMin = c_float(0)

            if self.c_lib.get_hmin(c_uint16(devInd), pointer(hMin)) < 0:
                raise Exception('Hmin error.')

            return hMin.value

        except Exception as e:
            print(e)

    def get_calibration_status(self, devInd):
        """
        Reads if the QRNG is calibrated or:
            DEFAULT = 0x0
            CALIBRATING = 0x5
            CALIB_SUCCED = 0x8
            CALIB_FAIL = 0x1
            I2C_ERROR = 0x3

        :param devInd: index of the device.
        :return: calibration status value as integer.
        """
        try:
            calibrated = c_int32(0)

            if self.c_lib.get_calibration_status(c_uint16(devInd), pointer(calibrated)) < 0:
                raise Exception('Calibration status error.')

            return calibrated.value

        except Exception as e:
            print(e)

    def check_thresholds(self, devInd):
        """
        Checks if the monitors of the system are between the correct operational limits.

        :param devInd: index of the device.
        :return: 0 if success, otherwise -1.
        """
        try:
            if self.c_lib.check_thresholds(c_uint16(devInd)) < 0:
                raise Exception('Check thresholds error.')

            return 0

        except Exception as e:
            print(e)

    def update_thresholds(self, devInd):
        """
        Update the thresholds of the monitors. This function must be called after calibration of the system and usually
        called in a regular period(get_delta_t) to maintain the alarms updated.

        :param devInd: index of the device.
        :return: 0 if success, otherwise -1.
        """
        try:
            if self.c_lib.update_thresholds(c_uint16(devInd)) < 0:
                raise Exception('Update thresholds error.')

            return 0

        except Exception as e:
            print(e)

    def get_monitor_value(self, monitor, devInd):
        """
        Read a specific monitor value

        :param monitor: monitor index to set. This value is in AlarmType enum.
        :param devInd: index of the device.
        :return: monitor value read as array. These values are in MonitorValue enum.
        """
        try:
            num = c_size_t(0)

            func = self.c_lib.get_monitor_value
            func.argtypes = [c_int32, POINTER(c_size_t), c_uint16]
            func.restype = POINTER(c_int32)

            arrMonitorValue = func(monitor, pointer(num), c_uint16(devInd))

            return np.array(np.fromiter(arrMonitorValue, dtype=np.int32, count=int(num.value)))

        except Exception as e:
            print(e)

    def set_monitor_enable(self, monitor, enable, devInd):
        """
        Enable a specific monitor.

        :param monitor: monitor index to set. This value is in AlarmType enum.
        :param enable: enable (True) or disable (False) monitor.
        :param devInd: index of the device.
        :return: 0 if success, otherwise -1.
        """
        try:
            self.c_lib.set_monitor_enable(monitor, c_bool(enable), c_uint16(devInd))

        except Exception as e:
            print(e)

    def set_monitor_enable_all(self, devInd):
        """
        Enable all monitors.

        :param devInd: index of the device.
        :return: 0 if success, otherwise -1.
        """
        for value in AlarmType:
            self.set_monitor_enable(value, True, devInd)
            time.sleep(0.1)

    def check_monitors(self, devInd):
        """
        Check all monitors.

        :param devInd: index of the device.
        :return: 0 if success, otherwise -1.
        """
        try:
            self.update_thresholds(devInd)

            self.check_thresholds(devInd)

            for value in AlarmType:
                mValue = self.get_monitor_value(value, devInd)

                for monitor in mValue:
                    if monitor < MonitorValue.HIGH_VALUE:
                        print('The system is at risk, it is necessary to stop for safety. ID: ' + str(devInd))
                        break

                    elif monitor < MonitorValue.OK:
                        print('One or more monitors are drifting. ID: ' + str(devInd))
                        break

        except Exception as e:
            print(e)

    def init_system_alarm(self, devInd):
        """
        Initialize alarm system.

        :param devInd: index of the device.
        :return: 0 if success, otherwise -1.
        """
        tSeconds = self.get_Delta_t()
        self.alarmTime = MyThread(tSeconds, self.check_monitors, args=[devInd])
        self.alarmTime.start()

    def stop_system_alarm(self):
        """
        Stop alarm system.

        :return: void.
        """
        self.alarmTime.cancel()
    # endregion MONITORS

    # region CAPTURE
    def get_random(self, num_bytes, devInd):
        """
        Get extracted random numbers.

        :param num_bytes: number of bytes to request.
        :param devInd: index of the device.
        :return: numpy array with the extracted random numbers.
        """
        return self.LALUser.get_random(num_bytes, devInd)

    def get_raw(self, num_bytes, devInd):
        """
        Get raw random numbers.

        :param num_bytes: number of bytes to request.
        :param devInd: index of the device.
        :return: numpy array with the raw random numbers.
        """
        return self.LALUser.get_raw(num_bytes, devInd)
    # endregion CAPTURE

    # region EXTRA
    def get_Delta_t(self):
        """
        Gets the time that the user should wait between to different calls of updateThresholds function.

        :return: Time in seconds.
        """
        try:
            return self.c_lib.get_Delta_t()

        except Exception as e:
            print(e)

    def setTimeout(self, seconds):
        """
        Set connection timeout.

        :return: void.
        """
        try:
            self.c_lib.setTimeout(seconds)

        except Exception as e:
            print(e)


class MyThread(Thread):
    def __init__(self, waitTime, function, args):
        Thread.__init__(self)
        self.stopped = Event()
        self.waitTime = waitTime
        self.function = function
        self.args = args[0]

    def run(self):
        while not self.stopped.wait(self.waitTime):
            self.function(self.args)

    def cancel(self):
        self.stopped.set()
    # endregion EXTRA
